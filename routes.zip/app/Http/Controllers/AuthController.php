<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Services\AuthServices;

class AuthController extends Controller
{
    private $authServices;
    private $request;

    public function __construct(
            Request $request,
            AuthServices $authServices
        ){
        $this->request = $request;
        $this->authServices = $authServices;
    }

    public function login(){
        return $this->authServices->login($this->request);
    }

    public function register(){
        return $this->authServices->register($this->request);
    }
}
