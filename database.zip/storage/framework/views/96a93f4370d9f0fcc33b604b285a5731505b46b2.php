<?php echo e($slot); ?>

<?php /**PATH C:\laravel\minilmn\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>