<?php $__env->startComponent('mail::message'); ?>
# Email Verification Forgot Password

Your four-digit code is 
<?php $__env->startComponent('mail::button', ['url' => '']); ?>
<?php echo e($message['code']); ?>

<?php echo $__env->renderComponent(); ?>

Berlaku sampai <?php echo e($message['expired']); ?>,<br>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\laravel\minilmn\resources\views/email.blade.php ENDPATH**/ ?>