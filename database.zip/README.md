user
 - id
 - username
 - email
 - password
 - parent ibu or ayah
 - kids_name 
 - umur
 - jenis_kelamin
